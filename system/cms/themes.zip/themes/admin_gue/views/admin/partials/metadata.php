    
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/ionicons/css/ionicons.min.css" rel="stylesheet">
 

    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Open Sans Font [ OPTIONAL ]-->
     

    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/css/bootstrap.min.css" rel="stylesheet">


    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/css/gue.css" rel="stylesheet">


    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/css/demo/nifty-demo-icons.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!--Demo [ DEMONSTRATION ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/css/demo/nifty-demo.min.css" rel="stylesheet">


        
    <!--Switchery [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/switchery/switchery.min.css" rel="stylesheet">


    <!--Bootstrap Select [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">


    <!--Bootstrap Tags Input [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.css" rel="stylesheet">


    <!--Chosen [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/chosen/chosen.min.css" rel="stylesheet">


    <!--noUiSlider [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/noUiSlider/nouislider.min.css" rel="stylesheet">


    <!--Select2 [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/select2/css/select2.min.css" rel="stylesheet">


    <!--Bootstrap Timepicker [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet">


    <!--Bootstrap Datepicker [ OPTIONAL ]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet">
 



    
    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--Pace - Page Load Progress Par [OPTIONAL]-->
    <link href="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/pace/pace.min.css" rel="stylesheet">
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/pace/pace.min.js"></script>


    <!--jQuery [ REQUIRED ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/jquery-2.2.4.min.js"></script>


    <!--BootstrapJS [ RECOMMENDED ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/bootstrap.min.js"></script>
    
    <script src="<?php echo base_url()?>assets/js/moment.js"></script>


    <!--NiftyJS [ RECOMMENDED ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/nifty.min.js"></script>

    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/jquery.mask.min.js"></script>




    <!--=================================================-->
     

    
    <!--Switchery [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/switchery/switchery.min.js"></script>


    <!--Bootstrap Select [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-select/bootstrap-select.min.js"></script>


    <!--Bootstrap Tags Input [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>


    <!--Chosen [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/chosen/chosen.jquery.min.js"></script>


    <!--noUiSlider [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/noUiSlider/nouislider.min.js"></script>


    <!--Select2 [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/select2/js/select2.min.js"></script>


    <!--Bootstrap Timepicker [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>


    <!--Bootstrap Datepicker [ OPTIONAL ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/plugins/bootbox/bootbox.min.js"></script>

    <!--Form Component [ SAMPLE ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/demo/form-component.js"></script>
    
     
    <!--Summernote [ OPTIONAL ]--> 
    <script src="<?php echo base_url()?>assets/js/bootstrap-datetimepicker.min.js"></script>

    <!--Form File Upload [ SAMPLE ]-->
    <script src="<?php echo base_url()?>system/cms/themes/admin_gue/js/demo/form-text-editor.js"></script>
    <script src="<?php echo base_url()?>system/cms/themes/admin_theme/js/jquery/jquery.min.js"></script> 
	<script type="text/javascript" src="<?php echo base_url()?>system/cms/themes/admin_theme/js/jquery/jquery-ui.min.js"></script> 
	<script type="text/javascript" src="<?php echo base_url()?>system/cms/themes/admin_theme/js/admin/functions.js"></script>
	<link href="<?php echo base_url()?>system/cms/themes/admin_theme/css/jquery/jquery-ui.css" rel="stylesheet">

<script type="text/javascript">
	var APPPATH_URI			= "<?php echo APPPATH_URI; ?>",
		SITE_URL			= "<?php echo rtrim(site_url(), '/') . '/'; ?>",
		BASE_URL			= "<?php echo BASE_URL; ?>",
		BASE_URI			= "<?php echo BASE_URI; ?>",
		UPLOAD_PATH			= "<?php echo UPLOAD_PATH; ?>",
		DEFAULT_TITLE		= "<?php echo $this->settings->site_name; ?>",
		DIALOG_MESSAGE		= "<?php echo lang('dialog.delete_message'); ?>";

	pyro.admin_theme_url 	= "<?php echo BASE_URL . $this->admin_theme->path; ?>";
	pyro.apppath_uri		= "<?php echo APPPATH_URI; ?>";
	pyro.base_uri			= "<?php echo BASE_URI; ?>";

	jQuery.noConflict();
	
</script>

<script type="text/javascript" src="<?php echo base_url()?>system/cms/themes/admin_theme/js/ckeditor/ckeditor.js"></script> 
<script type="text/javascript">

	var instance;

	function update_instance()
	{
		instance = CKEDITOR.currentInstance;
	}

	(function($) {
		$(function(){

			pyro.init_ckeditor = function(){
				$('textarea.wysiwyg-simple').ckeditor({
					toolbar: [
						 ['Bold', 'Italic', '-', 'NumberedList', 'BulletedList', '-', 'Link', 'Unlink']
					  ],
					width: '99%',
					height: 100,
					dialog_backgroundCoverColor: '#000',
					defaultLanguage: 'en',
					language: 'en'
				});
	
				$('textarea.wysiwyg-advanced').ckeditor({
					toolbar: [
						['Maximize'],
						['pyroimages', 'pyrofiles'],
						['Cut','Copy','Paste','PasteFromWord'],
						['Undo','Redo','-','Find','Replace'],
						['Link','Unlink'],
						['Table','HorizontalRule','SpecialChar'],
						['Bold','Italic','StrikeThrough'],
						['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
						['Format', 'FontSize', 'Subscript','Superscript', 'NumberedList','BulletedList','Outdent','Indent','Blockquote'],
						['ShowBlocks', 'RemoveFormat', 'Source']
					],
					extraPlugins: 'pyroimages,pyrofiles',
					width: '99%',
					height: 400,
					dialog_backgroundCoverColor: '#000',
					removePlugins: 'elementspath',
					defaultLanguage: 'en',
					language: 'en'
				});
			};
			pyro.init_ckeditor();

		});
	})(jQuery);
</script>

<?php echo $template['metadata']; ?>
