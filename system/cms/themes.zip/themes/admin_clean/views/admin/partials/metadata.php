    
     <!-- Bootstrap Core CSS -->
     <link href="<?php echo base_url()?>system/cms/themes/admin_clean/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/css/style.css" rel="stylesheet">
                              
    <!-- color CSS -->
    <link href="<?php echo base_url()?>system/cms/themes/admin_clean/css/colors/megna.css" id="theme" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo base_url()?>system/cms/themes/admin_clean/plugins/bower_components/dropify/dist/css/dropify.min.css">

<script type="text/javascript">
var pyro = {};
	var APPPATH_URI			= "<?php echo APPPATH_URI; ?>",
		SITE_URL			= "<?php echo rtrim(site_url(), '/') . '/'; ?>",
		BASE_URL			= "<?php echo BASE_URL; ?>",
		BASE_URI			= "<?php echo BASE_URI; ?>",
		UPLOAD_PATH			= "<?php echo UPLOAD_PATH; ?>",
		DEFAULT_TITLE		= "<?php echo $this->settings->site_name; ?>",
		DIALOG_MESSAGE		= "<?php echo lang('dialog.delete_message'); ?>";

	pyro.admin_theme_url 	= "<?php echo BASE_URL . $this->admin_theme->path; ?>";
	pyro.apppath_uri		= "<?php echo APPPATH_URI; ?>";
	pyro.base_uri			= "<?php echo BASE_URI; ?>";
 
	
</script>
 


