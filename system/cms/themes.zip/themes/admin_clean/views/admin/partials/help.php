<div id="help-container">
	<?php echo $help; ?>
</div>