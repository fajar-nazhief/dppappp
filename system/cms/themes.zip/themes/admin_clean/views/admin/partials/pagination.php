	
	<?php if(!empty($pagination['links'])): ?>
	
	<div class="paginate">
		<?php echo $pagination['links'];?>
	</div>
	
	<!-- Pages: </p> -->
	<?php endif; ?>